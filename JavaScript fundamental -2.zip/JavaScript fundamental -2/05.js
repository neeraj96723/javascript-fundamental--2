const guests = ["Anurag", "Mithun", "Alka", "Prabir", "Shivam", "Farman"];

// OUTPUT: Anurag, Mithun, Alka, Prabir, Shivam, Farman

console.log(guests.join(", "));
